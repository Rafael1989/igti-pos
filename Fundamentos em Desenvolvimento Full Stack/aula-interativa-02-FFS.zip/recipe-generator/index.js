const fs = require('fs').promises;
const uuid = require('uuid').v4;

const adjectives = [
  'Espetacular',
  'Excelente',
  'Exuberante',
  'Impressionante',
  'Sensacional',
  'Simples',
  'Fenomenal',
  'Super',
];

const dishes = [
  'bolo',
  'coxinha',
  'doce',
  'iogurte',
  'pastel',
  'pizza',
  'pudim',
  'sanduíche',
  'torta',
  'quindim',
  'bala',
  'pamonha',
];

const mainIngredients = [
  'abóbora',
  'aveia',
  'azeite',
  'calabresa',
  'cerveja',
  'chocolate',
  'chuchu',
  'frango',
  'milho',
  'morango',
  'uva',
  'vinho',
  'romã',
];

const data = { recipes: [] };

function headsOrTails() {
  return Math.ceil(Math.random() * 1000) % 2 === 0;
}

function getRandomIngredients() {
  return mainIngredients.filter(_ => headsOrTails()).sort();
}

function getRandomPrice() {
  return parseFloat((Math.random() * 100).toFixed(2), 10);
}

async function start() {
  for (const adjective of adjectives) {
    for (const food of dishes) {
      for (const ingredient of mainIngredients) {
        const title = `${adjective} ${food} de ${ingredient}`;

        const ingredients = Array.from(
          new Set([...getRandomIngredients(), ingredient, 'açúcar'])
        ).sort();

        const price = getRandomPrice();

        data.recipes.push({
          id: uuid(),
          title,
          ingredients,
          price,
        });
      }
    }
  }

  data.recipes.sort((a, b) => a.id.localeCompare(b.id));

  console.log(data);

  fs.writeFile('./recipes.json', JSON.stringify(data, null, 2));
}

start();
