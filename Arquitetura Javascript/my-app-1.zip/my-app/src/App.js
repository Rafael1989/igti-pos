import Component from './Component';

function App() {
  return (
    <div>
      <Component />
    </div>
  );
}

export default App;
