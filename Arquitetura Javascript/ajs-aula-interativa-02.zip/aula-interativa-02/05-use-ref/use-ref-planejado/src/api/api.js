function getRandomIntInclusive(min, max) {
  min = Math.ceil(min);
  max = Math.floor(max);
  return Math.floor(Math.random() * (max - min + 1)) + min;
}

export function apiGenerateMegaSena(quantity = 6) {
  const numbers = [];

  while (numbers.length < quantity) {
    const newNumber = getRandomIntInclusive(1, 60).toString().padStart(2, '0');

    if (!numbers.includes(newNumber)) {
      numbers.push(newNumber);
    }
  }

  return numbers.sort();
}
