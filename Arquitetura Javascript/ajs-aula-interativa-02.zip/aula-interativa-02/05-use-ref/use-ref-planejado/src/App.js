import { useEffect, useRef, useState } from 'react';
import { apiGenerateMegaSena } from './api/api';

export default function App() {
  const [task, setTask] = useState('');
  const [tasks, setTasks] = useState([]);
  const [numbers, setNumbers] = useState([]);
  const [quantity, setQuantity] = useState(1);

  const inputRef = useRef(null);
  const firstRender = useRef(true);

  useEffect(() => {
    if (firstRender.current) {
      firstRender.current = false;
      return;
    }

    const newNumbers = apiGenerateMegaSena(quantity);
    setNumbers(newNumbers);
  }, [quantity]);

  function handleTaskChange({ currentTarget }) {
    setTask(currentTarget.value);
  }

  function handleFormSubmit(event) {
    event.preventDefault();
    handleAddTask();
  }

  function handleAddTask() {
    if (task.trim() !== '') {
      setTasks([...tasks, task]);
    }
    setTask('');
    inputRef.current.focus();
  }

  function handleQuantityChange({ currentTarget }) {
    setQuantity(Number(currentTarget.value));
  }

  return (
    <div>
      <header>
        <div className="bg-gray-100 mx-auto p-4">
          <h1 className="text-center font-semibold text-xl">
            Exemplos com useRef
          </h1>
        </div>
      </header>

      <main>
        <div className="container mx-auto p-4">
          <div className="flex flex-row items-start justify-between">
            <section className="border p-2">
              <form className="flex flex-col" onSubmit={handleFormSubmit}>
                <label htmlFor="inputTask">Digite uma tarefa:</label>
                <div className="flex flex-row items-center justify-start">
                  <input
                    ref={inputRef}
                    className="border border-gray-800 p-1 flex-grow mr-4"
                    autoFocus
                    id="inputTask"
                    type="text"
                    value={task}
                    onChange={handleTaskChange}
                  />

                  <button
                    type="button"
                    className="bg-gray-200 p-1 rounded-lg hover:bg-gray-300"
                    onClick={handleAddTask}
                  >
                    Adicionar
                  </button>
                </div>
              </form>

              <ul>
                {tasks.map(task => {
                  return <li key={task}>{task}</li>;
                })}
              </ul>
            </section>

            <section className="border p-2 ml-2 flex-grow flex flex-col justify-center">
              <div className="flex flex-row items-center justify-between">
                <input
                  className="my-2 flex-grow mr-2"
                  type="range"
                  min="1"
                  max="6"
                  value={quantity}
                  onChange={handleQuantityChange}
                />
                <span>
                  Gerar <strong>{quantity}</strong> número(s) aleatório(s)
                </span>
              </div>

              <ul>
                {numbers.map(number => {
                  return <li key={number}>{number}</li>;
                })}
              </ul>
            </section>
          </div>
        </div>
      </main>
    </div>
  );
}
