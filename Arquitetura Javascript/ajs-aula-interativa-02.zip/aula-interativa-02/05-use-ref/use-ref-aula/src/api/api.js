function getRandomIntInclusive(min, max) {
  min = Math.ceil(min);
  max = Math.floor(max);
  return Math.floor(Math.random() * (max - min + 1)) + min;
}

export async function apiGenerateNumbers(quantity = 6) {
  const numbers = [];

  while (numbers.length < quantity) {
    const newNumber = getRandomIntInclusive(1, 60);

    if (!numbers.includes(newNumber)) {
      numbers.push(newNumber);
    }
  }

  return numbers.sort((a, b) => a - b);
}
