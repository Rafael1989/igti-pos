import { useEffect, useRef, useState } from 'react';
import { apiGenerateNumbers } from '../api/api';

export default function Numbers() {
  const [numbers, setNumbers] = useState([]);
  const [quantity, setQuantity] = useState(6);

  const firstRender = useRef(true);

  useEffect(() => {
    if (firstRender.current) {
      firstRender.current = false;
      return;
    }

    //apiGenerateNumbers(quantity).then(apiNumbers => setNumbers(apiNumbers));
    apiGenerateNumbers(quantity).then(setNumbers);
  }, [quantity]);

  function handleQuantityChange({ currentTarget }) {
    setQuantity(Number(currentTarget.value));
  }

  return (
    <div className="border m-2 p-1">
      <h2 className="text-center font-semibold">
        Gerador de números para a MegaSena
      </h2>

      <div className="flex flex-row items-center justify-start space-x-4">
        <input
          type="range"
          min="1"
          max="6"
          value={quantity}
          onChange={handleQuantityChange}
        />

        <span>{quantity}</span>
      </div>

      <div>{numbers.join(' ')}</div>
    </div>
  );
}
