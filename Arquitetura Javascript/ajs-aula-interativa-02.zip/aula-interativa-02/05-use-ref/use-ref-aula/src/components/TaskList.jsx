import { useRef, useState } from 'react';
import { v4 as uuid } from 'uuid';

export default function TaskList() {
  const [tasks, setTasks] = useState([]);
  const inputRef = useRef(null);

  function addTask(event) {
    event.preventDefault();
    const newTask = event.currentTarget.elements.inputTask.value;

    if (newTask.trim()) {
      setTasks([...tasks, { id: uuid(), description: newTask }]);
      inputRef.current.focus();
      inputRef.current.value = '';
    }
  }

  return (
    <div className="m-2 border p-2">
      <h2 className="text-center font-semibold">Tarefas</h2>

      <section className="flex flex-col">
        <form onSubmit={addTask}>
          <label htmlFor="inputTask">Tarefa:</label>

          <div className="flex flex-row items-center">
            <input
              ref={inputRef}
              autoFocus
              id="inputTask"
              type="text"
              className="border flex-grow"
            />
            <button className="bg-gray-200 p-1 ml-2 rounded-lg" type="submit">
              Adicionar
            </button>
          </div>
        </form>
      </section>

      <ul>
        {tasks.map(({ id, description }) => {
          return <li key={id}>{description}</li>;
        })}
      </ul>
    </div>
  );
}
