export default function ColorPicker({
  children: backgroundColor = '#000',
  onColorPickerClick = null,
}) {
  return (
    <div
      className="h-5 w-5 rounded-full border border-black cursor-pointer"
      style={{ backgroundColor }}
      onClick={() => onColorPickerClick(backgroundColor)}
    >
      &nbsp;
    </div>
  );
}
