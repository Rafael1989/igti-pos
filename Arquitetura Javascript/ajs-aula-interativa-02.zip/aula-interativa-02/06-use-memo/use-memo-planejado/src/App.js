import { useEffect, useMemo, useState } from 'react';
import ColorPicker from './components/ColorPicker';
import { apiGetAllCountries } from './api/api';

const COLORS = ['#e67e22', '#2ecc71', '#bdc3c7', '#34495e', '#ecf0f1', 'white'];

export default function App() {
  const [backgroundColor, setBackgroundColor] = useState('white');
  const [countryFilter, setCountryFilter] = useState('');
  const [countries, setCountries] = useState([]);

  useEffect(() => {
    apiGetAllCountries().then(backendCountries =>
      setCountries(backendCountries)
    );
  }, []);

  function handleColorChange(newColor) {
    setBackgroundColor(newColor);
  }

  // const filteredCountries = countries.filter(({ name }) => {
  //   if (!countryFilter || countryFilter.length < 3) {
  //     return false;
  //   }

  //   for (let i = 0; i < 100; i++) {
  //     console.log(i);
  //   }

  //   return name.toLowerCase().includes(countryFilter);
  // });

  const filteredCountries = useMemo(() => {
    return countries.filter(({ name }) => {
      if (!countryFilter || countryFilter.length < 3) {
        return false;
      }

      for (let i = 0; i < 100; i++) {
        console.log(i);
      }

      return name.toLowerCase().includes(countryFilter);
    });
  }, [countries, countryFilter]);

  return (
    <div>
      <header>
        <div className="bg-gray-100 mx-auto p-4">
          <h1 className="text-center font-semibold text-xl">
            useMemo planejado
          </h1>
        </div>
      </header>

      <main className="h-screen" style={{ backgroundColor }}>
        <div className="container mx-auto p-4">
          <div className="flex flex-row items-center justify-end space-x-1">
            {COLORS.map(color => {
              return (
                <ColorPicker key={color} onColorPickerClick={handleColorChange}>
                  {color}
                </ColorPicker>
              );
            })}
          </div>

          <div>
            <section className="flex flex-col">
              <label htmlFor="inputCountry">Digite o nome do país:</label>
              <input
                id="inputCountry"
                className="border border-black p-1"
                type="text"
                value={countryFilter}
                onChange={({ currentTarget }) =>
                  setCountryFilter(currentTarget.value)
                }
              />
            </section>
          </div>

          <ul className="mt-4">
            {filteredCountries.map(({ id, name, flag }) => {
              return (
                <li
                  key={id}
                  className="flex flex-row items-center justify-start space-x-2 mb-2"
                >
                  <img
                    src={flag}
                    alt={name}
                    width="100"
                    height="50"
                    className="border"
                  />
                  <span>{name}</span>
                </li>
              );
            })}
          </ul>
        </div>
      </main>
    </div>
  );
}
