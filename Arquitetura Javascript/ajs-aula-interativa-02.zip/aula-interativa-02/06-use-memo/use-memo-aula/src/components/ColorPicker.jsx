export default function ColorPicker({
  children: backgroundColor = '#000',
  onColorPickerClick = null,
}) {
  return (
    <div
      style={{ backgroundColor }}
      className="h-5 w-5 border border-black rounded-full cursor-pointer"
      onClick={() => onColorPickerClick(backgroundColor)}
    />
  );
}
