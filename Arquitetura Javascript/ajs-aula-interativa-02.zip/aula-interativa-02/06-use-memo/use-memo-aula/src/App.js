import { useEffect, useMemo, useState } from 'react';
import { apiGetAllCountries } from './api/api';
import ColorPicker from './components/ColorPicker';

//flatuicolors.com
const COLORS = [
  '#e67e22',
  '#2ecc71',
  '#bdc3c7',
  '#34495e',
  '#ecf0f1',
  'white',
  'black',
];

export default function App() {
  const [backgroundColor, setBackgroundColor] = useState('white');
  const [countries, setCountries] = useState([]);
  const [countryFilter, setCountryFilter] = useState('');

  useEffect(() => {
    apiGetAllCountries().then(setCountries);
  }, []);

  function handleColorChange(newColor) {
    setBackgroundColor(newColor);
  }

  function handleCountryFilterChange({ currentTarget }) {
    setCountryFilter(currentTarget.value);
  }

  // const filteredCountries = countries.filter(({ name }) => {
  //   if (!countryFilter || countryFilter.length < 3) {
  //     return false;
  //   }

  //   for (let i = 0; i < 100; i++) {
  //     console.log(i);
  //   }

  //   return name.toLowerCase().includes(countryFilter.toLowerCase());
  // });

  const filteredCountries = useMemo(() => {
    return countries.filter(({ name }) => {
      if (!countryFilter || countryFilter.length < 3) {
        return false;
      }

      for (let i = 0; i < 100; i++) {
        console.log(i);
      }

      return name.toLowerCase().includes(countryFilter.toLowerCase());
    });
  }, [countries, countryFilter]);

  return (
    <div>
      <header>
        <div className="bg-gray-100 mx-auto p-4">
          <h1 className="text-center font-semibold text-xl">useMemo</h1>
        </div>
      </header>

      <main className="h-screen" style={{ backgroundColor }}>
        <div className="flex flex-row items-center justify-end space-x-2 pt-4 pr-4">
          {COLORS.map(color => {
            return (
              <ColorPicker key={color} onColorPickerClick={handleColorChange}>
                {color}
              </ColorPicker>
            );
          })}
        </div>

        <div className="m-4 flex flex-col">
          <label htmlFor="inputFilter">Digite o nome do país:</label>
          <input
            id="inputFilter"
            className="border border-black"
            type="text"
            value={countryFilter}
            onChange={handleCountryFilterChange}
          />
        </div>

        <div>
          <ul>
            {filteredCountries.map(({ id, name, flag }) => {
              return (
                <li
                  key={id}
                  className="m-2 flex flex-row items-center space-x-2"
                >
                  <img src={flag} alt={name} width="100" height="50" />
                  <span>{name}</span>
                </li>
              );
            })}
          </ul>
        </div>
      </main>
    </div>
  );
}
