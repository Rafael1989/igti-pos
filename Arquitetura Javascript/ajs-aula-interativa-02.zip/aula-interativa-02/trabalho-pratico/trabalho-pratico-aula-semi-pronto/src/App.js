import { useEffect, useState } from 'react';

import {
  BsFillPlayFill as PlayIcon,
  BsFillStopFill as StopIcon,
} from 'react-icons/bs';

const BEST_BANDS = [
  { id: 'b1', name: 'Rush', votes: 0 },
  { id: 'b2', name: 'Dream Theater', votes: 0 },
  { id: 'b3', name: "Spock's Beard", votes: 0 },
  { id: 'b4', name: 'The Neal Morse Band', votes: 0 },
  { id: 'b5', name: 'Pain of Salvation', votes: 0 },
  { id: 'b6', name: 'Haken', votes: 0 },
];

const formatter = new Intl.NumberFormat();

function getRandomIntInclusive(min, max) {
  min = Math.ceil(min);
  max = Math.floor(max);
  return Math.floor(Math.random() * (max - min + 1)) + min;
}

function simulateVotes(items) {
  const newItems = items
    .map(item => ({
      ...item,
      votes: item.votes + getRandomIntInclusive(1, 1_000),
    }))
    .sort((a, b) => b.votes - a.votes);

  return newItems;
}

export default function App() {
  const [isVoting, setIsVoting] = useState(false);

  const [bands, setBands] = useState([
    ...BEST_BANDS.sort((a, b) => a.name.localeCompare(b.name)),
  ]);

  useEffect(() => {
    if (!isVoting) {
      return;
    }

    const interval = setInterval(() => {
      setBands(currentBands => simulateVotes(currentBands));
    }, 1_000);

    return () => {
      console.log('Finalizando interval...');
      clearInterval(interval);
    };
  }, [isVoting]);

  function start() {
    setIsVoting(true);
  }

  function reset() {
    setIsVoting(false);
    setBands(BEST_BANDS.sort((a, b) => a.name.localeCompare(b.name)));
  }

  return (
    <div>
      <header>
        <div className="bg-gray-100 mx-auto p-4">
          <h1 className="text-center font-semibold text-xl">
            Trabalho Prático - react-flip-toolkit
          </h1>
        </div>
      </header>

      <main>
        <div className="container mx-auto p-4">
          <section
            id="controls"
            className="flex flex-row justify-center my-4 space-x-8"
          >
            <button
              onClick={start}
              className="hover:bg-gray-100 p-1 rounded-lg"
            >
              <PlayIcon size={36} />
            </button>

            <button
              onClick={reset}
              className="hover:bg-gray-100 p-1 rounded-lg"
            >
              <StopIcon size={36} />
            </button>
          </section>

          <section id="bands">
            <ul>
              {bands.map(({ id, name, votes }) => {
                const formattedVotes = formatter.format(votes);

                return (
                  <li key={id} className="flex flex-row justify-between">
                    <span>{name}</span>
                    <span>{formattedVotes}</span>
                  </li>
                );
              })}
            </ul>
          </section>
        </div>
      </main>
    </div>
  );
}
