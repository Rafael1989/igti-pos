import { useEffect, useState } from 'react';
import { Flipper, Flipped } from 'react-flip-toolkit';

import {
  BsFillPlayFill as PlayIcon,
  BsFillStopFill as StopIcon,
} from 'react-icons/bs';

const BEST_BANDS = [
  { id: 'b1', name: 'Rush', votes: 0 },
  { id: 'b2', name: 'Dream Theater', votes: 0 },
  { id: 'b3', name: 'The Neal Morse Band', votes: 0 },
  { id: 'b4', name: 'Haken', votes: 0 },
  { id: 'b5', name: 'Biffy Clyro', votes: 0 },
  { id: 'b6', name: 'Pain of Salvation', votes: 0 },
].sort((a, b) => a.name.localeCompare(b.name));

function getRandomIntInclusive(min, max) {
  min = Math.ceil(min);
  max = Math.floor(max);
  return Math.floor(Math.random() * (max - min + 1)) + min;
}

function simulateVotes(items) {
  const newItems = items
    .map(item => {
      return { ...item, votes: item.votes + getRandomIntInclusive(1, 1_000) };
    })
    .sort((a, b) => b.votes - a.votes);

  return newItems;
}

export default function App() {
  const [isVoting, setIsVoting] = useState(false);
  const [bestBands, setBestBands] = useState([...BEST_BANDS]);

  useEffect(() => {
    if (!isVoting) {
      return;
    }

    const interval = setInterval(() => {
      setBestBands(currentBands => simulateVotes(currentBands));
    }, 1_000);

    return () => {
      console.log('Destruindo interval...');
      clearInterval(interval);
    };
  }, [isVoting]);

  const flipKey = bestBands
    .map(({ name, votes }) => `${name}_${votes}`)
    .join('');

  return (
    <div>
      <header>
        <div className="bg-gray-100 mx-auto p-4">
          <h1 className="text-center font-semibold text-xl">
            Exemplo com react-flip-toolkit - Raphael Gomide
          </h1>
        </div>
      </header>

      <main>
        <div className="container mx-auto p-4">
          <div className="flex flex-row items-center justify-center space-x-4">
            <button
              className="hover:bg-gray-200"
              onClick={() => setIsVoting(true)}
            >
              <PlayIcon size={36} />
            </button>

            <button
              className="hover:bg-gray-200"
              onClick={() => {
                setIsVoting(false);
                setBestBands([...BEST_BANDS]);
              }}
            >
              <StopIcon size={36} />
            </button>
          </div>

          <Flipper flipKey={flipKey}>
            <ul>
              {bestBands.map(({ id, name, votes }) => {
                return (
                  <Flipped key={id} flipId={id}>
                    <li className="flex flex-row items-center justify-between">
                      <span>{name}</span>
                      <span>{votes}</span>
                    </li>
                  </Flipped>
                );
              })}
            </ul>
          </Flipper>
        </div>
      </main>
    </div>
  );
}
