export default function LoginForm1({
  username,
  password,
  onDataChange,
  onFormSubmit,
}) {
  function handleChange(event, field) {
    onDataChange(event.currentTarget.value, field);
  }

  function handleFormSubmit(event) {
    event.preventDefault();
    onFormSubmit();
  }

  return (
    <form
      className="border mx-auto container my-4 p-4"
      onSubmit={handleFormSubmit}
    >
      <h2 className="text-center font-semibold">Login 1</h2>

      <section className="flex flex-col">
        <label htmlFor="username1">Usuário:</label>
        <input
          id="username1"
          className="border p-1"
          type="text"
          value={username}
          onChange={event => handleChange(event, 'username')}
        />
      </section>

      <section className="flex flex-col">
        <label htmlFor="password1">Senha:</label>
        <input
          id="password1"
          className="border p-1"
          type="password"
          value={password}
          onChange={event => handleChange(event, 'password')}
        />
      </section>

      <section className="mt-4 flex justify-end">
        <button
          type="submit"
          className="bg-gray-200 p-2 rounded-lg hover:bg-gray-300"
        >
          Login
        </button>
      </section>
    </form>
  );
}
