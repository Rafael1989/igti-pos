export default function LoginForm2({ onFormSubmit }) {
  function handleFormSubmit(event) {
    event.preventDefault();

    onFormSubmit(
      event.currentTarget.elements.username2.value,
      event.currentTarget.elements.password2.value
    );
  }

  return (
    <form
      className="border mx-auto container my-4 p-4"
      onSubmit={handleFormSubmit}
    >
      <h2 className="text-center font-semibold">Login 2</h2>

      <section className="flex flex-col">
        <label htmlFor="username2">Usuário:</label>
        <input
          id="username2"
          className="border p-1"
          type="text"
          defaultValue="dream_theater"
        />
      </section>

      <section className="flex flex-col">
        <label htmlFor="password2">Senha:</label>
        <input
          id="password2"
          className="border p-1"
          type="password"
          defaultValue="erotomania"
        />
      </section>

      <section className="mt-4 flex justify-end">
        <button
          type="submit"
          className="bg-gray-200 p-2 rounded-lg hover:bg-gray-300"
        >
          Login
        </button>
      </section>
    </form>
  );
}
