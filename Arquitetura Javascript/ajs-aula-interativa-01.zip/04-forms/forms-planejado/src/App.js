import { useState } from 'react';
import LoginForm1 from './components/LoginForm1';
import LoginForm2 from './components/LoginForm2';

export default function App() {
  const [username, setUsername] = useState('dream_theater');
  const [password, setPassword] = useState('erotomania');
  const [validation1, setValidation1] = useState('');

  const [validation2, setValidation2] = useState('');

  function handleDataChange1(newValue, field) {
    switch (field) {
      case 'username':
        setUsername(newValue);
        break;

      case 'password':
        setPassword(newValue);
        break;

      default:
        break;
    }
  }

  function handleFormSubmit1() {
    if (username === 'rush' && password === 'yyz') {
      setValidation1('Login e senha corretos!');
    } else {
      setValidation1('Tente novamente!');
    }
  }

  function handleFormSubmit2(username2, password2) {
    if (username2 === 'rush' && password2 === 'yyz') {
      setValidation2('Login e senha corretos!');
    } else {
      setValidation2('Tente novamente!');
    }
  }

  return (
    <>
      <LoginForm1
        username={username}
        password={password}
        onDataChange={handleDataChange1}
        onFormSubmit={handleFormSubmit1}
      />
      <div className="text-center">{validation1}</div>

      <LoginForm2 onFormSubmit={handleFormSubmit2} />
      <div className="text-center">{validation2}</div>
    </>
  );
}
