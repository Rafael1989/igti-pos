export default function LoginForm1({
  username,
  password,
  onChange,
  onFormSubmit,
}) {
  function handleUsernameChange(event) {
    const newUsername = event.currentTarget.value;
    onChange('username', newUsername);
  }

  function handlePasswordChange(event) {
    const newPassword = event.currentTarget.value;
    onChange('password', newPassword);
  }

  function handleFormSubmit(event) {
    event.preventDefault();
    onFormSubmit();
  }

  return (
    <form onSubmit={handleFormSubmit}>
      <section className="flex flex-col">
        <label>Usuário:</label>
        <input
          className="border border-gray-500"
          type="text"
          value={username}
          onChange={handleUsernameChange}
        />
      </section>

      <section className="flex flex-col">
        <label>Senha:</label>
        <input
          className="border border-gray-500"
          type="password"
          value={password}
          onChange={handlePasswordChange}
        />
      </section>

      <section className="flex flex-row justify-end">
        <button type="submit" className="bg-gray-200 p-2 mt-2 rounded-lg ">
          Login
        </button>
      </section>
    </form>
  );
}
