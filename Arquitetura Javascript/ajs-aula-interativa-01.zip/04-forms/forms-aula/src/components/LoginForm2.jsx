export default function LoginForm2({ onFormSubmit }) {
  function handleFormSubmit(event) {
    event.preventDefault();

    const username = event.currentTarget.elements.input_username.value;
    const password = event.currentTarget.elements.input_password.value;
    onFormSubmit(username, password);
  }

  return (
    <form onSubmit={handleFormSubmit}>
      <section className="flex flex-col">
        <label htmlFor="input_username">Usuário:</label>
        <input
          id="input_username"
          className="border border-gray-500"
          type="text"
          defaultValue="dream_theater"
        />
      </section>

      <section className="flex flex-col">
        <label htmlFor="input_password">Senha:</label>
        <input
          id="input_password"
          className="border border-gray-500"
          type="password"
          defaultValue="erotomania"
        />
      </section>

      <section className="flex flex-row justify-end">
        <button type="submit" className="bg-gray-200 p-2 mt-2 rounded-lg ">
          Login
        </button>
      </section>
    </form>
  );
}
