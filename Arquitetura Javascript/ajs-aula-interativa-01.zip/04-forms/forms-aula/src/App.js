import { useState } from 'react';
import LoginForm1 from './components/LoginForm1';
import LoginForm2 from './components/LoginForm2';

export default function App() {
  const [username, setUsername] = useState('dream_theater');
  const [password, setPassword] = useState('erotomania');
  const [message, setMessage] = useState('');

  // const [fields, setFields] = useState({
  //   username: 'dream_theater',
  //   password: 'erotomania',
  // });

  function handleFormChange(field, value) {
    switch (field) {
      case 'username':
        setUsername(value);
        break;

      case 'password':
        setPassword(value);
        break;

      default:
        break;
    }
  }

  function validateLogin() {
    if (username === 'rush' && password === 'yyz') {
      setMessage('Login válido');
      return;
    }

    setMessage('Login inválido!');
  }

  function validateLogin2(username, password) {
    if (username === 'rush' && password === 'yyz') {
      setMessage('Login válido');
      return;
    }

    setMessage('Login inválido!');
  }

  return (
    <div>
      <header>
        <div className="bg-gray-100 mx-auto p-4">
          <h1 className="text-center font-semibold text-xl">React Forms</h1>
        </div>
      </header>

      <main>
        <div className="container mx-auto p-4">
          <LoginForm1
            username={username}
            password={password}
            onChange={handleFormChange}
            onFormSubmit={validateLogin}
          />

          <span>{message}</span>

          <LoginForm2 onFormSubmit={validateLogin2} />
        </div>
      </main>
    </div>
  );
}
