import Component2 from './components/Component2';
import Component1 from './components/Component1';

export default function App() {
  return (
    <div>
      <header>
        <div className="bg-gray-100 mx-auto p-4">
          <h1 className="text-center font-semibold text-xl">
            Projeto base para o Módulo React I
          </h1>
        </div>
      </header>

      <main>
        <div className="container mx-auto p-4">
          <Component2 />
          <Component1 />
        </div>
      </main>
    </div>
  );
}
