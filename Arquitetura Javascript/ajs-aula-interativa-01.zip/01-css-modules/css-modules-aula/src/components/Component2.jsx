export default function Component2() {
  return <div className="highlight">Component 2</div>;
}
