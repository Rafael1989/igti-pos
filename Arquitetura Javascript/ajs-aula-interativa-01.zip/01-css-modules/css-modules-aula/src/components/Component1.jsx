import cssClasses from './Component1.module.css';

export default function Component1() {
  return <div className={cssClasses.highlight}>Component 1</div>;
}
