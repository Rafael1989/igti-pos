import Component1 from './components/Component1';
import Component2 from './components/Component2';

export default function App() {
  console.log('Teste no console do navegador');

  return (
    <div>
      <Component1 />
      <Component2 />
    </div>
  );
}
