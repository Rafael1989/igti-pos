import styles from './Component1.module.css';

export default function Component1() {
  return <div className={`m-4 text-4xl ${styles.highlight}`}>Component 1</div>;
}
