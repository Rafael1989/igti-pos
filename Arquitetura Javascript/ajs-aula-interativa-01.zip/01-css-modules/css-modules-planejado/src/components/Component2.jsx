export default function Component2() {
  return <div className="m-4 text-4xl highlight">Component 2</div>;
}
