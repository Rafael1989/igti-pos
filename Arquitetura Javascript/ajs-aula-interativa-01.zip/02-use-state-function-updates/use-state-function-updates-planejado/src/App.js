import { useState } from 'react';

function longDelay() {
  return new Promise((resolve, _) => {
    setTimeout(() => {
      resolve();
    }, 1000);
  });
}

export default function App() {
  const [counterValue, setCounterValue] = useState(0);

  function incrementBy1() {
    console.log(counterValue);
    setCounterValue(counterValue + 1);
  }

  function handleButtonClick1() {
    incrementBy1();
    incrementBy1();
    incrementBy1();
    incrementBy1();
    incrementBy1();
  }

  function handleButtonClick2() {
    setCounterValue(currentValue => {
      console.log(currentValue);
      return currentValue + 1;
    });

    setCounterValue(currentValue => {
      console.log(currentValue);
      return currentValue + 1;
    });

    setCounterValue(currentValue => {
      console.log(currentValue);
      return currentValue + 1;
    });

    setCounterValue(currentValue => {
      console.log(currentValue);
      return currentValue + 1;
    });

    setCounterValue(currentValue => {
      console.log(currentValue);
      return currentValue + 1;
    });
  }

  async function handleButtonClick3() {
    await longDelay();
    setCounterValue(counterValue + 1);
  }

  async function handleButtonClick4() {
    await longDelay();
    setCounterValue(counterValue => counterValue + 1);
  }

  return (
    <div>
      <header>
        <div className="bg-gray-100 mx-auto p-4">
          <h1 className="text-center font-semibold text-xl">
            Alternativas para a setter function de useState
          </h1>
        </div>
      </header>

      <main>
        <div className="container mx-auto p-4">
          <p>Valor atual: {counterValue}</p>

          <div className="mt-2">
            <button
              onClick={handleButtonClick1}
              className="p-1 bg-gray-200 hover:bg-gray-300 w-40 rounded-lg"
            >
              Incremento 1
            </button>
          </div>

          <div className="mt-2">
            <button
              onClick={handleButtonClick2}
              className="p-1 bg-gray-200 hover:bg-gray-300 w-40 rounded-lg"
            >
              Incremento 2
            </button>
          </div>

          <div className="mt-2">
            <button
              onClick={handleButtonClick3}
              className="p-1 bg-gray-200 hover:bg-gray-300 w-80 rounded-lg"
            >
              Incremento 3 (clique várias vezes)
            </button>
          </div>

          <div className="mt-2">
            <button
              onClick={handleButtonClick4}
              className="p-1 bg-gray-200 hover:bg-gray-300 w-80 rounded-lg"
            >
              Incremento 4 (clique várias vezes)
            </button>
          </div>
        </div>
      </main>
    </div>
  );
}
