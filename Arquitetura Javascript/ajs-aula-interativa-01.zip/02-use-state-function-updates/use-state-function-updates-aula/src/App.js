import { useState } from 'react';

function wait1Second() {
  return new Promise((resolve, reject) => {
    setTimeout(() => {
      resolve();
    }, 1000);
  });
}

function initializeCounter() {
  for (let i = 0; i < 10_000; i++) {
    console.log(i);
  }
  return 1;
}

export default function App() {
  // const state = useState(0);
  // const counter = state[0];
  // const setCounter = state[1];
  const [counter, setCounter] = useState(() => initializeCounter());

  function handleCounter1() {
    setCounter(counter + 1);
    setCounter(counter + 1);
    setCounter(counter + 1);
    setCounter(counter + 1);
    setCounter(counter + 1);
  }

  function handleCounter2() {
    setCounter(currentCounter => currentCounter + 1);
    setCounter(currentCounter => currentCounter + 1);
    setCounter(currentCounter => currentCounter + 1);
    setCounter(currentCounter => currentCounter + 1);
    setCounter(currentCounter => currentCounter + 1);
  }

  async function handleCounter3() {
    await wait1Second();
    setCounter(counter + 1);
  }

  async function handleCounter4() {
    await wait1Second();
    setCounter(currentCounter => currentCounter + 1);
  }

  return (
    <div>
      <header>
        <div className="bg-gray-100 mx-auto p-4">
          <h1 className="text-center font-semibold text-xl">
            React Function Updates
          </h1>
        </div>
      </header>

      <main>
        <div className="text-xl text-center mt-4">{counter}</div>

        <button
          onClick={handleCounter1}
          className="bg-gray-200 p-1 rounded-lg m-2 hover:bg-gray-300"
        >
          Teste 1
        </button>

        <button
          onClick={handleCounter2}
          className="bg-gray-200 p-1 rounded-lg m-2 hover:bg-gray-300"
        >
          Teste 2
        </button>

        <button
          onClick={handleCounter3}
          className="bg-gray-200 p-1 rounded-lg m-2 hover:bg-gray-300"
        >
          Teste 3
        </button>

        <button
          onClick={handleCounter4}
          className="bg-gray-200 p-1 rounded-lg m-2 hover:bg-gray-300"
        >
          Teste 4
        </button>
      </main>
    </div>
  );
}
