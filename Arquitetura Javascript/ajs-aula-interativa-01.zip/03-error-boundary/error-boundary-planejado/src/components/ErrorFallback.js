export default function ErrorFallback({ error }) {
  return (
    <div className="bg-red-300 text-red-900 p-4">
      Erro não detectado em desenvolvimento: <strong>{error.message}</strong>
    </div>
  );
}
