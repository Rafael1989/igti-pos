export default function Reverse({ children = 'Texto a ser invertido' }) {
  return <div>{children.split('').reverse().join('')}</div>;
}
