export default function Reverse({ children }) {
  return <div>{children.split('').reverse().join('')}</div>;
}
