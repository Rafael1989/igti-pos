import express from 'express';
import fs from 'fs';
import { promisify } from 'util';

const router = express.Router();
const writeFile = promisify(fs.writeFile);
const readFile = promisify(fs.readFile);

router.post('/', async (req, res) => {
    try{
        let account = req.body;
        const data = JSON.parse(await readFile(global.fileName, 'utf8'));
        account = { id: data.nextId++, ...account, timestamp: new Date()};
        data.accounts.push(account)
        await writeFile(global.fileName, JSON.stringify(data));

        res.end();

        logger.info(`POST /account - ${JSON.stringify(account)}`);
    }catch(err){
        res.status(400).send({ error: err.message });
    }
});

router.put('/deposita', async (req, res) => {
    try{
        const newBalance = req.body;
        const data = JSON.parse(await readFile(global.fileName, 'utf8'));
        let oldBalanceIndex = data.accounts.findIndex(account => account.id === newBalance.id);
        if(oldBalanceIndex < 0){
            res.status(404).send({ error: "Essa conta não existe." });
        }
        if(req.body.balance < 0){
            res.status(400).send({ error: "Favor informar um valor positivo." });
        }
        newBalance.timestamp = new Date();
        newBalance.balance += data.accounts[oldBalanceIndex].balance;
        data.accounts[oldBalanceIndex] = newBalance;
        await writeFile(global.fileName, JSON.stringify(data));

        res.end();

        logger.info(`PUT /account/deposita - ${JSON.stringify(account)}`);
    } catch (err){
        res.status(400).send({ error: err.message });
    }
});

router.put('/saca', async (req, res) => {
    try{
        const newBalance = req.body;
        const data = JSON.parse(await readFile(global.fileName, 'utf8'));
        let oldBalanceIndex = data.accounts.findIndex(account => account.id === newBalance.id);
        if(oldBalanceIndex < 0){
            res.status(404).send({ error: "Essa conta não existe." });
        }
        if(req.body.balance < 0){
            res.status(400).send({ error: "Favor informar um valor positivo." });
        }
        if(req.body.balance > data.accounts[oldBalanceIndex].balance){
            res.status(400).send({ error: "Sua conta não tem saldo suficiente." });
        }
        newBalance.timestamp = new Date();
        newBalance.balance = data.accounts[oldBalanceIndex].balance - newBalance.balance;
        data.accounts[oldBalanceIndex] = newBalance;
        await writeFile(global.fileName, JSON.stringify(data));

        res.end();

        logger.info(`PUT /account/saca - ${JSON.stringify(account)}`);
    } catch (err){
        res.status(400).send({ error: err.message });
    }
});

router.get('/:id', async (req, res) => {
    try{
        const data = JSON.parse(await readFile(global.fileName, 'utf8'));
        const account = data.accounts.find(account => account.id === parseInt(req.params.id, 10));
        if(account){
            res.send("O saldo da conta é: " + account.balance);
        }else{
            res.status(404).send({ error: "A conta informada não existe." });
        }
        logger.info(`GET /account - ${req.params.id}`);
    }catch(err){
        res.status(400).send({ error: err.message });
    }
});

router.delete('/:id', async (req, res) => {
    try{
        const data = JSON.parse(await readFile(global.fileName, 'utf8'));
        data.accounts = data.accounts.filter(account => account.id !== parseInt(req.params.id, 10));
        await writeFile(global.fileName, JSON.stringify(data));

        res.end();

        logger.info(`DELETE /account - ${req.params.id}`);
    }catch(err){
        res.status(400).send({ error: err.message });
    }
});

export default router;