import { useState } from 'react';

import ShoppingCartPage from './pages/ShoppingCartPage';
import { ThemeContext } from './contexts/ThemeContext';
import { FiSun as LightIcon, FiMoon as DarkIcon } from 'react-icons/fi';

export default function App() {
  const [theme, setTheme] = useState('light');

  function toggleTheme() {
    const newTheme = theme === 'light' ? 'dark' : 'light';
    setTheme(newTheme);
  }

  const currentIcon =
    theme === 'light' ? (
      <LightIcon size="36" color="black" />
    ) : (
      <DarkIcon size="36" color="white" />
    );

  const backgroundClassName = theme === 'light' ? 'bg-white' : 'bg-gray-900';

  return (
    <ThemeContext.Provider value={theme}>
      <div className={backgroundClassName}>
        <div
          className={`p-2 flex justify-end cursor-pointer`}
          onClick={toggleTheme}
        >
          {currentIcon}
        </div>

        <ShoppingCartPage />
      </div>
    </ThemeContext.Provider>
  );
}
