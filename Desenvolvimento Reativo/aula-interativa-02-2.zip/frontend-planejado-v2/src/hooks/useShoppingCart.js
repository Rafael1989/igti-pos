import { useReducer } from 'react';

const initialShoppingCart = { items: [] };

function getTotal(items) {
  return items.reduce((accumulator, { quantity, price }) => {
    return accumulator + quantity * price;
  }, 0);
}

function foundItem(items, id) {
  return items.findIndex(item => item.id === id) > -1;
}

function shoppingCartReducer(state, action) {
  switch (action.type) {
    case 'ADD_ITEM': {
      let updatedItems = [];

      if (foundItem(state.items, action.game.id)) {
        updatedItems = state.items.map(item => {
          if (item.id === action.game.id) {
            return { ...item, quantity: item.quantity + 1 };
          }

          return { ...item };
        });
      } else {
        updatedItems = [
          ...state.items,
          {
            id: action.game.id,
            quantity: 1,
            price: action.game.price,
          },
        ];
      }

      return { items: updatedItems };
    }

    case 'REMOVE_ITEM': {
      let updatedItems = [...state.items];

      if (foundItem(state.items, action.game.id)) {
        updatedItems = state.items.map(item => {
          if (item.id === action.game.id) {
            return { ...item, quantity: item.quantity - 1 };
          }

          return { ...item };
        });
      }

      return { items: updatedItems };
    }

    case 'CLEAR': {
      return initialShoppingCart;
    }

    default:
      throw new Error(`Não há implementação para a ação ${action.type}`);
  }
}

export default function useShoppingCart() {
  const [state, dispatch] = useReducer(
    shoppingCartReducer,
    initialShoppingCart
  );

  const total = getTotal(state.items);

  return [{ items: state.items, total }, dispatch];
}
