import { useContext, useEffect, useState } from 'react';
import Header from '../components/Header';
import Main from '../components/Main';

import { apiGetAllGames } from '../api/apiService';
import Games from '../components/Games';
import Loading from '../components/Loading';
import Game from '../components/Game';
import ShoppingItem from '../components/ShoppingItem';
import MoneyFormatter from '../components/MoneyFormatter';
import { AiOutlineShoppingCart as ShoppingCartIcon } from 'react-icons/ai';

import useShoppingCart from '../hooks/useShoppingCart';
import GameHeader from '../components/GameHeader';
import Title from '../components/Title';
import GameItems from '../components/GameItems';
import GameContainer from '../components/GameContainer';
import ClearShoppingCart from '../components/ClearShoppingCart';
import { ThemeContext } from '../contexts/ThemeContext';

export default function ShoppingCartPage() {
  const [loading, setLoading] = useState(true);
  const [games, setGames] = useState([]);

  // prettier-ignore
  const [shoppingCart, dispatch] = 
    useShoppingCart();

  const theme = useContext(ThemeContext);

  useEffect(() => {
    async function getAllGames() {
      const allGames = await apiGetAllGames();

      setTimeout(() => {
        setGames(allGames);
        setLoading(false);
      }, 500);
    }

    getAllGames();
  }, []);

  function handleAdd(game) {
    dispatch({ type: 'ADD_ITEM', game });
  }

  function handleRemove(game) {
    dispatch({ type: 'REMOVE_ITEM', game });
  }

  function handleClear() {
    dispatch({ type: 'CLEAR' });
  }

  let mainContent = <Loading />;

  if (!loading) {
    mainContent = (
      <Games>
        <Title>{games.length} jogo(s) disponível(is)</Title>

        <GameHeader>
          <ShoppingCartIcon
            size="36"
            color={theme === 'light' ? 'black' : 'white'}
          />

          <MoneyFormatter>{shoppingCart.total}</MoneyFormatter>

          <ClearShoppingCart onClearShoppingCart={handleClear} />
        </GameHeader>

        <GameItems>
          {games.map(game => {
            // prettier-ignore
            const quantity =
              shoppingCart.items.find(item => item.id === game.id)?.quantity || 0;

            return (
              <GameContainer key={game.id}>
                <Game>{game}</Game>

                <ShoppingItem
                  quantity={quantity}
                  onAdd={handleAdd}
                  onRemove={handleRemove}
                >
                  {game}
                </ShoppingItem>
              </GameContainer>
            );
          })}
        </GameItems>
      </Games>
    );
  }

  return (
    <>
      <Header>react-shopping-cart</Header>
      <Main>{mainContent}</Main>
    </>
  );
}
