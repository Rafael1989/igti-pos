import { useContext } from 'react';
import { ThemeContext } from '../contexts/ThemeContext';

export default function GameContainer({ children }) {
  const theme = useContext(ThemeContext);

  const borderColor = theme === 'light' ? 'border-gray-200' : 'border-gray-500';

  return (
    <div
      className={`border ${borderColor} m-2 p-4 flex flex-col space-y-4 w-96`}
    >
      {children}
    </div>
  );
}
