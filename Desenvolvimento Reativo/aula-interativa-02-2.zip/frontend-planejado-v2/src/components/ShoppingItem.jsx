import { useContext } from 'react';
import { ThemeContext } from '../contexts/ThemeContext';
import Button from './Button';

export default function ShoppingItem({
  quantity,
  onAdd,
  onRemove,
  children: game,
}) {
  function handleAddItem() {
    onAdd(game);
  }

  function handleRemoveItem() {
    onRemove(game);
  }

  const theme = useContext(ThemeContext);

  const inputClasses =
    theme === 'light'
      ? 'bg-white text-gray-900 border-gray-200'
      : 'bg-gray-900 text-gray-50 border-gray-700';

  return (
    <div className="flex flex-row items-center justify-center space-x-4">
      <Button
        type="bad"
        onButtonClick={handleRemoveItem}
        disabledButton={quantity === 0}
      >
        -
      </Button>

      <input
        className={`border p-2 w-14 justify-center ${inputClasses}`}
        type="number"
        min="0"
        max="10"
        value={quantity}
        disabled
        readOnly
      />

      <Button
        type="good"
        onButtonClick={handleAddItem}
        disabledButton={quantity === 10}
      >
        +
      </Button>
    </div>
  );
}
