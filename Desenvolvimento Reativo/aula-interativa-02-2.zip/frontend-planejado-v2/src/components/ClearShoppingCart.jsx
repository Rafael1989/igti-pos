import { BsFillTrashFill as ClearShoppingCartIcon } from 'react-icons/bs';

export default function ClearShoppingCart({ onClearShoppingCart = null }) {
  function handleClick() {
    if (onClearShoppingCart) {
      onClearShoppingCart();
    }
  }

  return (
    <div className="cursor-pointer" onClick={handleClick}>
      <ClearShoppingCartIcon size={36} color="darkred" />
    </div>
  );
}
