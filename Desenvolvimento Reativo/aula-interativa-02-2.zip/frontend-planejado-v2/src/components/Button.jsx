import { useContext } from 'react';
import { ThemeContext } from '../contexts/ThemeContext';

export default function Button({
  type = 'good',
  children: value = 'Botão',
  onButtonClick,
  disabledButton,
}) {
  const theme = useContext(ThemeContext);

  const classType =
    type === 'good'
      ? theme === 'light'
        ? 'bg-green-200 text-gray-900'
        : 'bg-green-900 text-gray-50'
      : theme === 'light'
      ? 'bg-red-200 text-gray-900'
      : 'bg-red-900 text-gray-50';

  return (
    <button
      disabled={disabledButton}
      onClick={onButtonClick}
      className={`w-10 p-1 px-3  
                  text-2xl font-semibold
                  disabled:opacity-50
                  ${classType}`}
    >
      {value}
    </button>
  );
}
