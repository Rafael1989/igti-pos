export default function GameHeader({ children }) {
  return (
    <div className="flex flex-row items-center justify-end space-x-4 my-8 text-2xl">
      {children}
    </div>
  );
}
