import { useContext } from 'react';
import { ThemeContext } from '../contexts/ThemeContext';

export default function Title({ children }) {
  const theme = useContext(ThemeContext);

  const textColor = theme === 'light' ? 'text-gray-900' : 'text-gray-100';

  return (
    <h2 className={`font-semibold text-center text-3xl ${textColor}`}>
      {children}
    </h2>
  );
}
