export default function Games({ children }) {
  return <div className="p-2">{children}</div>;
}
