import { useContext } from 'react';
import { ThemeContext } from '../contexts/ThemeContext';
import MoneyFormatter from './MoneyFormatter';

export default function Game({ children: game }) {
  const { name, image, price } = game;

  const theme = useContext(ThemeContext);

  const gameTextColor = theme === 'light' ? 'text-gray-900' : 'text-gray-100';
  const priceBackground = theme === 'light' ? 'bg-green-50' : 'bg-green-900';

  return (
    <div className="flex flex-col justify-start space-x-2">
      <img src={image} className="object-cover h-96 w-full" alt={name} />

      <ul className="flex flex-row items-center justify-between">
        <li className={`font-semibold ${gameTextColor}`}>{name}</li>

        <li className={`${priceBackground} p-2`}>
          <MoneyFormatter>{price}</MoneyFormatter>
        </li>
      </ul>
    </div>
  );
}
