import { useContext } from 'react';
import { ThemeContext } from '../contexts/ThemeContext';

export default function Header({ children = 'Conteúdo de <Header />' }) {
  const theme = useContext(ThemeContext);

  const textColor = theme === 'light' ? 'text-black' : 'text-gray-100';

  return (
    <header>
      <div className={`mx-auto p-4 ${textColor}`}>
        <h1 className="text-center font-semibold text-4xl">{children}</h1>
      </div>
    </header>
  );
}
