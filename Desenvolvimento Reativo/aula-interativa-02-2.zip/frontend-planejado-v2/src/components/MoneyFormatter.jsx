import { useContext } from 'react';
import { ThemeContext } from '../contexts/ThemeContext';

const moneyFormatter = Intl.NumberFormat('pt-br', {
  style: 'currency',
  currency: 'BRL',
});

export default function MoneyFormatter({ children: value }) {
  const theme = useContext(ThemeContext);

  const textColor = theme === 'light' ? 'text-gray-900' : 'text-gray-100';

  return (
    <span className={`font-semibold ${textColor}`}>
      {moneyFormatter.format(value)}
    </span>
  );
}
