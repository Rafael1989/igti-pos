export default function GameItems({ children }) {
  return (
    <div
      className={`p-2 
                  flex flex-col items-center justify-center 
                  sm:flex-row sm:flex-wrap`}
    >
      {children}
    </div>
  );
}
