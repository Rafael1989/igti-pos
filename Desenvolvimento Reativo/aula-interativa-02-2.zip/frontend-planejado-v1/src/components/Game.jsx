import MoneyFormatter from './MoneyFormatter';

export default function Game({ children: game }) {
  const { name, image, price } = game;

  return (
    <div className="flex flex-col justify-start space-x-2">
      <img src={image} className="object-cover h-96 w-full" alt={name} />

      <ul className="flex flex-row items-center justify-between">
        <li className="font-semibold">{name}</li>
        <li className="bg-green-50 p-2">
          <MoneyFormatter>{price}</MoneyFormatter>
        </li>
      </ul>
    </div>
  );
}
