export default function Button({
  type = 'good',
  children: value = 'Botão',
  onButtonClick,
  disabledButton,
}) {
  const classType = type === 'good' ? 'bg-green-200' : 'bg-red-200';

  return (
    <button
      disabled={disabledButton}
      onClick={onButtonClick}
      className={`bg-gray-200 text-gray-900
                    w-10 p-1 px-3  
                    text-2xl font-semibold
                    disabled:opacity-20                                         
                    ${classType}`}
    >
      {value}
    </button>
  );
}
