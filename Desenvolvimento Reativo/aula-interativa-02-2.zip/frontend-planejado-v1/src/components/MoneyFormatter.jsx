const moneyFormatter = Intl.NumberFormat('pt-br', {
  style: 'currency',
  currency: 'BRL',
});

export default function MoneyFormatter({ children: value }) {
  return <span className="font-semibold">{moneyFormatter.format(value)}</span>;
}
