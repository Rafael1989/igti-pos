import Button from './Button';

export default function ShoppingItem({ gameId, quantity, onAdd, onRemove }) {
  function handleAddItem() {
    onAdd(gameId);
  }

  function handleRemoveItem() {
    onRemove(gameId);
  }

  console.log(quantity);

  return (
    <div className="flex flex-row items-center justify-center space-x-4">
      <Button
        type="bad"
        onButtonClick={handleRemoveItem}
        disabledButton={quantity === 0}
      >
        -
      </Button>

      <input
        className="border p-2"
        type="number"
        min="0"
        max="10"
        value={quantity}
        disabled
        readOnly
      />

      <Button
        type="good"
        onButtonClick={handleAddItem}
        disabledButton={quantity === 10}
      >
        +
      </Button>
    </div>
  );
}
