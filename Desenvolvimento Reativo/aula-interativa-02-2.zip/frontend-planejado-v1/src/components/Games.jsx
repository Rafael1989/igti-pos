export default function Games({ children }) {
  return <div className="border p-2">{children}</div>;
}
