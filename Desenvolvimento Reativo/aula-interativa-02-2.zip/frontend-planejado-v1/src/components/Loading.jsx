import ClipLoader from 'react-spinners/ClipLoader';

export default function Loading() {
  return (
    <div className="flex flex-row items-center justify-center mt-4">
      <ClipLoader />
    </div>
  );
}
