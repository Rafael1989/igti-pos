import { get } from './httpService';

export async function apiGetAllGames() {
  const allGames = await get('http://localhost:3001/games');
  return allGames;
}
