import { Fragment, useEffect, useState } from 'react';
import Header from '../components/Header';
import Main from '../components/Main';

import { apiGetAllGames } from '../api/apiService';
import Games from '../components/Games';
import Loading from '../components/Loading';
import Game from '../components/Game';
import ShoppingItem from '../components/ShoppingItem';
import MoneyFormatter from '../components/MoneyFormatter';
import { AiOutlineShoppingCart as ShoppingCartIcon } from 'react-icons/ai';

export default function ShoppingCartPage() {
  const [loading, setLoading] = useState(true);
  const [games, setGames] = useState([]);
  const [shoppingCart, setShoppingCart] = useState({ items: [] });

  useEffect(() => {
    async function getAllGames() {
      const allGames = await apiGetAllGames();

      setTimeout(() => {
        setGames(allGames);
        setLoading(false);
      }, 500);
    }

    getAllGames();
  }, []);

  function handleAdd(itemId) {
    const updatedShoppingCart = { ...shoppingCart };

    // prettier-ignore
    const index = 
      updatedShoppingCart.items.findIndex(item => item.id === itemId);

    if (index >= 0) {
      updatedShoppingCart.items[index].quantity++;
    } else {
      const { price } = games.find(game => game.id === itemId);

      updatedShoppingCart.items.push({ id: itemId, price, quantity: 1 });
    }

    setShoppingCart(updatedShoppingCart);
  }

  function handleRemove(itemId) {
    const updatedShoppingCart = { ...shoppingCart };

    // prettier-ignore
    const index = 
      updatedShoppingCart.items.findIndex(item => item.id === itemId);

    if (index >= 0) {
      updatedShoppingCart.items[index].quantity--;
      setShoppingCart(updatedShoppingCart);
    }
  }

  let mainContent = <Loading />;

  if (!loading) {
    // prettier-ignore
    const totalShoppingCart = 
      shoppingCart
        .items
        .reduce((accumulator, { price, quantity }) => accumulator + price * quantity, 0);

    mainContent = (
      <Games>
        <h2 className="font-semibold text-center text-4xl">
          {games.length} jogo(s) disponível(is)
        </h2>

        <div className="flex flex-row items-center justify-end space-x-4 my-8 text-2xl">
          <ShoppingCartIcon size="36" />
          <MoneyFormatter>{totalShoppingCart}</MoneyFormatter>
        </div>

        <div className="flex flex-col sm:flex-row sm:flex-wrap">
          {games.map(game => {
            const quantity =
              shoppingCart.items.find(item => item.id === game.id)?.quantity ||
              0;

            return (
              <div
                key={game.id}
                className="border m-2 p-2 flex flex-col space-y-4"
              >
                <Game>{game}</Game>

                <ShoppingItem
                  gameId={game.id}
                  quantity={quantity}
                  onAdd={handleAdd}
                  onRemove={handleRemove}
                />
              </div>
            );
          })}
        </div>
      </Games>
    );
  }

  return (
    <>
      <Header>React Shopping Cart</Header>

      <Main>{mainContent}</Main>
    </>
  );
}
