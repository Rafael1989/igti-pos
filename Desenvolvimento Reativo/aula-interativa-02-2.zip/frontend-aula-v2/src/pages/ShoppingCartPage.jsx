import { Fragment, useEffect, useState } from 'react';
import Header from '../components/Header';
import Main from '../components/Main';

import { apiGetAllProducts } from '../api/apiService';
import Loading from '../components/Loading';
import Products from '../components/Products';
import Product from '../components/Product';
import TextInput from '../components/TextInput';
import ShoppingCart from '../components/ShoppingCart';

export default function ShoppingCartPage() {
  const [products, setProducts] = useState([]);
  const [loading, setLoading] = useState(true);
  const [filter, setFilter] = useState('');

  useEffect(() => {
    // IIFE
    // (async function getAllProducts() {
    //   const backendProducts = await apiGetAllProducts();
    //   console.log(backendProducts);
    // })();

    async function getAllProducts() {
      const backendProducts = await apiGetAllProducts();
      console.log(backendProducts);
      setProducts(backendProducts);

      setTimeout(() => {
        setLoading(false);
      }, 500);
    }

    getAllProducts();
  }, []);

  function handleFilterChange(newFilter) {
    setFilter(newFilter);
  }

  function handleAdd(gameId) {
    setProducts(
      products.map(product => {
        if (product.id === gameId) {
          return { ...product, quantity: Math.min(10, product.quantity + 1) };
        }
        return product;
      })
    );
  }

  function handleRemove(gameId) {
    setProducts(
      products.map(product => {
        if (product.id === gameId) {
          return { ...product, quantity: Math.max(0, product.quantity - 1) };
        }
        return product;
      })
    );
  }

  function handleClearShoppingCart() {
    setProducts(products.map(product => ({ ...product, quantity: 0 })));
  }

  const filteredProducts =
    filter.trim() === ''
      ? [...products]
      : products.filter(product => product.name.includes(filter));

  let data = (
    <div className="flex flex-row items-center justify-center">
      <Loading />
    </div>
  );

  if (!loading) {
    const totalShoppingCart = products.reduce(
      (accumulator, { quantity, price }) => {
        return accumulator + quantity * price;
      },
      0
    );

    data = (
      <>
        <TextInput inputValue={filter} onInputChange={handleFilterChange} />

        <ShoppingCart onClear={handleClearShoppingCart}>
          {totalShoppingCart}
        </ShoppingCart>

        <Products>
          {filteredProducts.map(product => {
            const { id } = product;

            return (
              <Product key={id} onAdd={handleAdd} onRemove={handleRemove}>
                {product}
              </Product>
            );
          })}
        </Products>
      </>
    );
  }

  return (
    <div>
      <Header type="ok">react-shopping-cart</Header>

      <Main>{data}</Main>
    </div>
  );
}
