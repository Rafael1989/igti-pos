import { get } from './httpService';

export async function apiGetAllProducts() {
  const allProducts = await get('http://localhost:3001/games');

  return allProducts.map(product => {
    return { ...product, quantity: 0 };
  });
}
