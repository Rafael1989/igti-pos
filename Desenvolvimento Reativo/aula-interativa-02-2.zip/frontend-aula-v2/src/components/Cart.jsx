export default function Cart({ quantity = 0, onAdd = null, onRemove = null }) {
  function handleAddClick() {
    if (onAdd) {
      onAdd();
    }
  }

  function handleRemoveClick() {
    if (onRemove) {
      onRemove();
    }
  }

  return (
    <div className="mt-4 text-xl">
      <button
        onClick={handleRemoveClick}
        className="bg-red-200 p-1 w-8 rounded-lg"
      >
        -
      </button>

      <input
        className="w-10 border mx-4 text-center"
        type="text"
        value={quantity}
        readOnly
      />

      <button
        onClick={handleAddClick}
        className="bg-green-200 p-1 w-8 rounded-lg"
      >
        +
      </button>
    </div>
  );
}
