export default function Header({ children = 'Título do Header', type = 'ok' }) {
  const backgroundClassName =
    type === 'ok'
      ? 'bg-green-200'
      : type === 'error'
      ? 'bg-red-200'
      : 'bg-yellow-200';

  return (
    <header>
      <div className={`mx-auto p-1 ${backgroundClassName}`}>
        <h1 className="text-center font-semibold text-xl">{children}</h1>
      </div>
    </header>
  );
}
