import Cart from './Cart';
import MoneyFormatter from './MoneyFormatter';

export default function Product({
  children: product,
  onAdd = null,
  onRemove = null,
}) {
  const { name, image, price, quantity } = product;

  function handleCartAdd() {
    if (onAdd) {
      onAdd(product.id);
    }
  }

  function handleCartRemove() {
    if (onRemove) {
      onRemove(product.id);
    }
  }

  return (
    <div className="border m-2 rounded-sm p-4 flex flex-row items-center space-x-4">
      <img width="200px" height="100px" src={image} alt={name} />

      <ul>
        <li>{name}</li>

        <li>
          <MoneyFormatter>{price}</MoneyFormatter>
        </li>

        <li>
          <Cart
            quantity={quantity}
            onAdd={handleCartAdd}
            onRemove={handleCartRemove}
          />
        </li>
      </ul>
    </div>
  );
}
