import { GrCart as ShoppingCartIcon } from 'react-icons/gr';
import { AiOutlineDelete as DeleteIcon } from 'react-icons/ai';
import MoneyFormatter from './MoneyFormatter';

export default function ShoppingCart({ children: value = 0, onClear = null }) {
  function handleClear() {
    if (onClear) {
      onClear();
    }
  }

  return (
    <div className="flex flex-row items-center justify-end space-x-4 my-4">
      <ShoppingCartIcon size={36} />

      <span className="text-2xl">
        <MoneyFormatter>{value}</MoneyFormatter>
      </span>

      <DeleteIcon
        onClick={handleClear}
        className="cursor-pointer"
        size={36}
        color="darkred"
      />
    </div>
  );
}
