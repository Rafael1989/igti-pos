import ClipLoader from 'react-spinners/ClipLoader';

export default function Loading() {
  return <ClipLoader />;
}
