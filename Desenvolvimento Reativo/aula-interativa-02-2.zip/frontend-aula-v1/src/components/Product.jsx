export default function Product({ children: product }) {
  const { name, image, price } = product;

  return (
    <div className="border m-2 rounded-sm p-4 flex flex-row items-center space-x-4">
      <img width="200px" height="100px" src={image} alt={name} />

      <ul>
        <li>{name}</li>
        <li>{price}</li>
      </ul>
    </div>
  );
}
