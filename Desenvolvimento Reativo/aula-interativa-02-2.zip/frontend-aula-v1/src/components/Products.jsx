export default function Products({ children }) {
  return <div className="border p-2">{children}</div>;
}
