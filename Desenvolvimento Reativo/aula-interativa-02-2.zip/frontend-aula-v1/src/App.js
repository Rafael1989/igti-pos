import ShoppingCartPage from './pages/ShoppingCartPage';

export default function App() {
  return <ShoppingCartPage />;
}
