const fs = require('fs').promises;

function getNewPrice() {
  return parseFloat((50 + Math.random() * 100).toFixed(2));
}
async function start() {
  const currentGames = JSON.parse(await fs.readFile('./games.json', 'utf-8'));

  const gamesWithPrices = currentGames.games.map(game => {
    return { ...game, price: getNewPrice() };
  });

  console.log(gamesWithPrices);

  fs.writeFile(
    './gamesWithPrices.json',
    JSON.stringify(
      { games: gamesWithPrices.filter((_, index) => index < 50) },
      null,
      2
    )
  );
}

start();
