import { Fragment, useEffect, useState } from 'react';
import Header from '../components/Header';
import Main from '../components/Main';

import { apiGetAllProducts } from '../api/apiService';
import Loading from '../components/Loading';
import Products from '../components/Products';
import Product from '../components/Product';
import TextInput from '../components/TextInput';

export default function ShoppingCartPage() {
  const [products, setProducts] = useState([]);
  const [loading, setLoading] = useState(true);
  const [filter, setFilter] = useState('');

  useEffect(() => {
    // IIFE
    // (async function getAllProducts() {
    //   const backendProducts = await apiGetAllProducts();
    //   console.log(backendProducts);
    // })();

    async function getAllProducts() {
      const backendProducts = await apiGetAllProducts();
      setProducts(backendProducts);

      setTimeout(() => {
        setLoading(false);
      }, 500);
    }

    getAllProducts();
  }, []);

  function handleFilterChange(newFilter) {
    setFilter(newFilter);
  }

  const filteredProducts =
    filter.trim() === ''
      ? [...products]
      : products.filter(product => product.name.includes(filter));

  let data = (
    <div className="flex flex-row items-center justify-center">
      <Loading />
    </div>
  );

  if (!loading) {
    data = (
      <>
        <TextInput inputValue={filter} onInputChange={handleFilterChange} />

        <Products>
          {filteredProducts.map(product => {
            const { id } = product;

            return <Product key={id}>{product}</Product>;
          })}
        </Products>
      </>
    );
  }

  return (
    <div>
      <Header type="ok">react-shopping-cart</Header>

      <Main>{data}</Main>
    </div>
  );
}
