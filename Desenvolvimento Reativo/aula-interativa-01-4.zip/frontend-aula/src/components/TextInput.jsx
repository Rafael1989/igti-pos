export default function TextInput({ inputValue = '', onInputChange = null }) {
  function handleInputChange(event) {
    if (onInputChange) {
      onInputChange(event.currentTarget.value);
    }
  }

  return (
    <input
      className="border w-full mb-4 p-2"
      type="text"
      value={inputValue}
      placeholder="Filtro"
      onChange={handleInputChange}
    />
  );
}
