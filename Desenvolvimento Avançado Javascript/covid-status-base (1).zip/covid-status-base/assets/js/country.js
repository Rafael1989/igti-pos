const countryE = document.getElementById('cmbCountry');
const dataE = document.getElementById('cmbData');
const date_startE = document.getElementById('date_start');
const date_endE = document.getElementById('date_end');
const filtroE = document.getElementById('filtro');
const kpiconfirmedE = document.getElementById('kpiconfirmed');
const kpideathsE = document.getElementById('kpideaths');
const kpirecoveredE = document.getElementById('kpirecovered');
let textGraph = '';

const graphLinesE = document.getElementById('linhas');
let linhas;

window.addEventListener('load', () => {
    load();
});

// Função reutilizável da API
async function fetchE(url) {
    const res = await axios.get(`https://api.covid19api.com/${url}`);

    return res.data;
}

async function load() {
    // EventListerners
    const dateNow = new Date(
        new Date().getFullYear(),
        new Date().getMonth(),
        new Date().getDate()
    );

    filtroE.addEventListener('click', loadData);

    console.log('Carregando paises');
    await Promise.all([fetchE('countries')]).then(([countries]) => {
        loadComboCountrys(countries);
    });
    console.log('Fim carga de paiseses');
}

function loadComboCountrys(countries) {
    countries.sort((a, b) => {
        let x = a.Country.toUpperCase();
        let y = b.Country.toUpperCase();
        return x === y ? 0 : x > y ? 1 : -1;
    });

    countries.map((country) => {
        let optionT = document.createElement('option');
        optionT.text = country.Country;
        optionT.value = country.Slug;

        countryE.appendChild(optionT);
    });
}

async function loadData() {
    console.log('Loading data...');

    const data_start = date_startE.value;
    const data_end = date_endE.value;
    const country = countryE.value;

    //Active Confirmed Deaths Recoved
    let tActiveDays = 0;
    let tConfirmedDays = 0;
    let tDeathsDays = 0;
    let tRecovedDays = 0;

    let valuesData = [];
    let datesData = [];
    let medData = [];

    // https://api.covid19api.com/country/south-africa?from=2020-03-01T00:00:00Z&to=2020-04-01T00:00:00Z
    const url = `country/${country}?from=${data_start}T00:00:00Z&to=${data_end}T00:00:00Z`;
    await Promise.all([fetchE(url)]).then(([datesCountry]) => {
        console.log(datesCountry);

        if (datesCountry.length > 0) {
            tActiveDays = datesCountry[datesCountry.length - 1].Active;
            tConfirmedDays = datesCountry[datesCountry.length - 1].Confirmed;
            tDeathsDays = datesCountry[datesCountry.length - 1].Deaths;
            tRecovedDays = datesCountry[datesCountry.length - 1].Recovered;

            for (let i = 1; i < datesCountry.length; i++) {
                let tempValue = 0;

                //Confirmed Deaths Recovered
                if (dataE.value === 'Confirmed') {
                    if (i === 0) {
                        valuesData.push(datesCountry[i].Confirmed);
                    } else {
                        tempValue =
                            datesCountry[i].Confirmed -
                            datesCountry[i - 1].Confirmed;
                        valuesData.push(tempValue);
                    }
                    datesData.push(formatDate(datesCountry[i].Date));
                } else {
                    if (dataE.value === 'Deaths') {
                        if (i === 0) {
                            valuesData.push(datesCountry[i].Deaths);
                        } else {
                            tempValue =
                                datesCountry[i].Deaths -
                                datesCountry[i - 1].Deaths;
                            valuesData.push(tempValue);
                        }
                        datesData.push(formatDate(datesCountry[i].Date));
                    } else {
                        if (dataE.value === 'Recovered') {
                            if (i === 0) {
                                valuesData.push(datesCountry[i].Recovered);
                            } else {
                                tempValue =
                                    datesCountry[i].Recovered -
                                    datesCountry[i - 1].Recovered;
                                valuesData.push(tempValue);
                            }
                            datesData.push(formatDate(datesCountry[i].Date));
                        }
                    }
                }
            }
        }
        // grafic
        console.log(valuesData);
        console.log(datesData);
        console.log(datesCountry);
        // Totalizadores // kpiconfirmed  kpideaths  kpirecovered
        kpiconfirmedE.innerHTML = tConfirmedDays.toLocaleString('PT');
        kpideathsE.innerHTML = tDeathsDays.toLocaleString('PT');
        kpirecoveredE.innerHTML = tRecovedDays.toLocaleString('PT');

        medData = _.meanBy(valuesData, (v) => v);

        if (!(linhas === undefined)) linhas.destroy();

        linhas = new Chart(document.getElementById('linhas'), {
            type: 'line',
            data: {
                labels: datesData,
                datasets: [
                    {
                        data: valuesData,
                        label: `Número de ${dataE.options[
                            dataE.selectedIndex
                        ].getAttribute('data')}`,
                        borderColor: 'rgb(60,60,60)',
                        backgroundColor: 'rgb(60,186,159,01)',
                    },
                    {
                        data: Array(valuesData.length).fill(medData),
                        label: `Média de ${dataE.options[
                            dataE.selectedIndex
                        ].getAttribute('data')}`,
                        borderColor: 'rgb(10,10,159)',
                        backgroundColor: 'rgb(60,186,159,0.1)',
                    },
                ],
            },
            options: {
                responsive: true,
                plugins: {
                    legend: {
                        display: true,
                        position: 'top', //top, bottom, left, rigth
                    },
                    title: {
                        display: true,
                        text: 'Curva diária de Covid-19',
                    },
                    layout: {
                        padding: {
                            left: 100,
                            right: 100,
                            top: 50,
                            bottom: 10,
                        },
                    },
                },
            },
        });
    });
}
/*
async function loadSummary() {
    // console.log(summary);

    if (comboE.value === 'Global') {
        await Promise.all([fetchE('summary')]).then(([summary]) => {
            confirmedE.innerHTML = summary.Global.TotalConfirmed.toLocaleString(
                'PT'
            );
            deathE.innerHTML = summary.Global.TotalDeaths.toLocaleString('PT');
            recoveredE.innerHTML = summary.Global.TotalRecovered.toLocaleString(
                'PT'
            );
            activeE.innerHTML = (
                summary.Global.TotalConfirmed -
                summary.Global.TotalDeaths +
                summary.Global.TotalRecovered
            ).toLocaleString('PT');
        });
    } else {
        let startDate = new Date(todayE.value);
        let endDate = new Date(
            startDate.getFullYear(),
            startDate.getMonth(),
            startDate.getDate() + 1,
            -3,
            0,
            1,
            0
        );

        startDate = new Date(
            startDate.getFullYear(),
            startDate.getMonth(),
            startDate.getDate() - 1,
            -3,
            0,
            0,
            0
        );

        await Promise.all([
            fetchCountry(comboE.value, startDate, endDate),
        ]).then(([fetchCountry]) => {
            if (fetchCountry.length > 0) {
                console.log(fetchCountry);
                const index = fetchCountry.length - 1;
                confirmedE.innerHTML = fetchCountry[
                    index
                ].Confirmed.toLocaleString('PT');
                deathE.innerHTML = fetchCountry[index].Deaths.toLocaleString(
                    'PT'
                );
                recoveredE.innerHTML = fetchCountry[
                    index
                ].Recovered.toLocaleString('PT');
                activeE.innerHTML = fetchCountry[index].Active.toLocaleString(
                    'PT'
                );
                carregaDeltas(fetchCountry);
            } else {
                confirmedE.innerHTML = 0;
                deathE.innerHTML = 0;
                recoveredE.innerHTML = 0;
                activeE.innerHTML = 0;
            }
        });
    }
}
function carregaDeltas(fetchCountry) {
    let yConfirmedDelta;
    let yDeathDelta;
    let yRecoveredDelta;
    let yActiveDelta;
    let tConfirmedDelta;
    let tDeathDelta;
    let tRecoveredDelta;
    let tActiveDelta;

    // Carrega dados dos Deltas
    yConfirmedDelta = fetchCountry[1].Confirmed - fetchCountry[0].Confirmed;
    yDeathDelta = fetchCountry[1].Deaths - fetchCountry[0].Deaths;
    yRecoveredDelta = fetchCountry[1].Recovered - fetchCountry[0].Recovered;
    yActiveDelta = fetchCountry[1].Active - fetchCountry[0].Active;

    tConfirmedDelta = fetchCountry[2].Confirmed - fetchCountry[1].Confirmed;
    tDeathDelta = fetchCountry[2].Deaths - fetchCountry[1].Deaths;
    tRecoveredDelta = fetchCountry[2].Recovered - fetchCountry[1].Recovered;
    tActiveDelta = fetchCountry[2].Active - fetchCountry[1].Active;

    // calcula deltas
    insertDailyData(
        'tconfirmed',
        tConfirmedDelta,
        yConfirmedDelta < tConfirmedDelta
    );
    insertDailyData('tdeath', tDeathDelta, yDeathDelta < tDeathDelta);
    insertDailyData(
        'trecovered',
        tRecoveredDelta,
        yRecoveredDelta < tRecoveredDelta
    );
    insertDailyData('tactive', tActiveDelta, yActiveDelta < tActiveDelta);
    console.log('fim delta');
}

function insertDailyData(element, value, increase) {
    if (increase) {
        document.getElementById(
            element
        ).innerHTML = `\u2B9D Diário ${value.toLocaleString('PT')}`;
    } else {
        document.getElementById(
            element
        ).innerHTML = `\u2B9F Diário ${value.toLocaleString('PT')}`;
    }
}
*/

function formatNumber(number) {
    return number.toLocaleString('pt-BR');
}

function formatDate(date) {
    var d = new Date(date),
        month = '' + (d.getMonth() + 1),
        day = '' + d.getDate(),
        year = d.getFullYear();

    if (month.length < 2) month = '0' + month;
    if (day.length < 2) day = '0' + day;

    return [day, month, year].join('.').toString();
}
