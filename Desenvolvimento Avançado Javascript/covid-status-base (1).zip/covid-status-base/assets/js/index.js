const urlSummary = "https://api.covid19api.com/summary";

window.addEventListener("load", init);

const totalConfirmados = document.getElementById("confirmed");
const totalMortes = document.getElementById("death");
const totalRecuperados = document.getElementById("recovered");
const dataAtualizacao = document.getElementById("date");
let novosConfirmados = 0;
let novasMortes = 0;
let novosRecuperados = 0;
let countries = undefined;


async function init() {
    let res = await axios.get(urlSummary);
    totalConfirmados.innerHTML = res.data.Global.TotalConfirmed;
    totalMortes.innerHTML = res.data.Global.TotalDeaths;
    totalRecuperados.innerHTML = res.data.Global.TotalRecovered;
    novosConfirmados = res.data.Global.NewConfirmed;
    novasMortes = res.data.Global.NewDeaths;
    novosRecuperados = res.data.Global.NewRecovered;
    countries = res.data.Countries;

    countries = countries.sort(function(a, b) {
        return b.TotalDeaths - a.TotalDeaths;
    });
    let dt = new Date(res.data.Global.Date);
    let dataFormatada = `${
        (dt.getMonth()+1).toString().padStart(2, '0')}.${
        dt.getDate().toString().padStart(2, '0')}.${
        dt.getFullYear().toString().padStart(4, '0')} ${
        dt.getHours().toString().padStart(2, '0')}:${
        dt.getMinutes().toString().padStart(2, '0')}`;
    dataAtualizacao.append(dataFormatada);

    let pizza = new Chart(document.getElementById("pizza"), {
        type: 'pie',
        data: {
            labels: ["Confirmados", "Recuperados", "Mortes"],
            datasets: [ {
                data: [novosConfirmados, novosRecuperados, novasMortes],
                backgroundColor: ["#3e95cd", "#3c8523", "#42F39f"]
            }
            ]
        },
        options: {
            responsive: true,
            plugins: {
                legend: {
                    position: 'top'
                },
                title: {
                    display: true,
                    text: "Distribuição de novos casos"
                }
            }
        }
    });

    let bar = new Chart(document.getElementById("barras"), {
        type: 'bar',
        data: {
            labels: [countries[0].Country, countries[1].Country, countries[2].Country, countries[3].Country, countries[4].Country, countries[5].Country, countries[6].Country, countries[7].Country, countries[8].Country, countries[9].Country],
            datasets: [
                {
                    label: "",
                    data: [countries[0].TotalDeaths, countries[1].TotalDeaths, countries[2].TotalDeaths, countries[3].TotalDeaths, countries[4].TotalDeaths, countries[5].TotalDeaths, countries[6].TotalDeaths, countries[7].TotalDeaths, countries[8].TotalDeaths, countries[9].TotalDeaths],
                    backgroundColor: "#0F0F0F"
                }
    
            ]
        },
        options: {
            reponsive: true,
            plugins: {
                legend: {
                    display: false,
                    position: 'top'
                },
                title: {
                    display: true,
                    text: "Total de Mortes por país - Top 10"
                }
            }
        }
    });
}


